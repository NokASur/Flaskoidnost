all_tasks = []

# task_name/Day/Times/Level
all_tasks.append(["hang on a bar for 25 seconds", 1, 3, 1])
all_tasks.append(["push up on the low bar 10 times", 1, 5, 1])

all_tasks.append(["push up on the low bar 20 times", 3, 3, 1])
all_tasks.append(["light jogging for 10 minutes", 3, 1, 1])

all_tasks.append(["push up on the low bar 30 times ", 5, 1, 1])
all_tasks.append(["light jogging for 25 minutes", 5, 1, 1])

all_tasks.append(["pull ups, try ur max", 2, 3, 2])
all_tasks.append(["negative pull ups, 15 times", 2, 4, 2])

all_tasks.append(["push ups, try ur max", 4, 3, 2])
all_tasks.append(["reversed push ups 10 times", 4, 3, 2])
all_tasks.append(["hang on a bar, try your max", 4, 4, 2])

all_tasks.append(["sit ups, try 80% from your max", 6, 4, 2])
all_tasks.append(["push ups", 6, 25, 2])

all_tasks.append(["pull ups 50% out of your max", 1, 2, 3])
all_tasks.append(["pull ups 80% out of your max", 1, 1, 3])
all_tasks.append(["pull ups, try your max", 1, 1, 3])
all_tasks.append(["push-ups on bars 20 times", 1, 2, 3])

all_tasks.append(["sit ups 80% out of your max", 2, 4, 3])
all_tasks.append(["hang on a bar, try your max", 2, 4, 3])
all_tasks.append(["push ups on your fists 40 times", 2, 1, 3])

all_tasks.append(["wide sit ups 80% out of your max", 4, 4, 3])
all_tasks.append(["pull ups, try your max", 4, 2, 3])
all_tasks.append(["push ups, try your max", 4, 2, 3])

all_tasks.append(["bulgarian squats 80% out of your max", 5, 4, 3])
all_tasks.append(["wide sit ups 80% out of your max", 5, 4, 3])
all_tasks.append(["rise on toes 5 minutes", 5, 1, 3])

all_tasks.append(["push-ups from the floor with narrow arms, try your max", 1, 3, 4])
all_tasks.append(["bulgarian squats 80% out of your max", 1, 5, 4])
all_tasks.append(["biceps pull-ups x20", 1, 4, 4])

all_tasks.append(["pull-ups on the low bar perpendicular to the floor, try your max", 2, 2, 4])
all_tasks.append(["push ups, try 80% out of your max", 2, 4, 4])
all_tasks.append(["bars push ups on the chest (round the back, elbows at 45 degrees), try your max", 2, 3, 4])

all_tasks.append(["push ups, try your max", 4, 4, 4])
all_tasks.append(["pull ups, try your max", 4, 4, 4])
all_tasks.append(["run for 5km", 4, 1, 4])

all_tasks.append(["bars push ups on the chest (round the back, elbows at 45 degrees), try your max", 5, 3, 4])
all_tasks.append(["pull-ups on the low bar perpendicular to the floor, try your max", 5, 2, 4])
all_tasks.append(["push ups, try 80% out of your max", 5, 4, 4])

all_tasks.append(["push-ups from the floor with narrow arms, try your max", 7, 3, 4])
all_tasks.append(["bulgarian squats 80% out of your max", 7, 5, 4])
all_tasks.append(["biceps pull-ups x20", 7, 4, 4])

all_tasks.append(["push-ups from the floor with narrow arms, try your max", 1, 3, 5])
all_tasks.append(["run 7 km", 1, 1, 5])
all_tasks.append(["biceps pull-ups x25", 1, 4, 5])

all_tasks.append(["bars push ups on the chest (round the back, elbows at 45 degrees), try your max", 2, 3, 5])
all_tasks.append(["pull-ups on the low bar perpendicular to the floor, try your max", 2, 2, 5])
all_tasks.append(["push ups, try 80% out of your max", 2, 4, 5])

all_tasks.append(["run 8 km", 3, 1, 5])
all_tasks.append(["push ups try your max", 3, 4, 5])
all_tasks.append(["exit by force on the horizontal bar, try max", 3, 3, 5])

all_tasks.append(["pull ups 15 times", 5, 10, 5])
all_tasks.append(["push ups 30 times", 5, 10, 5])
all_tasks.append(["sprint 500 meters", 5, 3, 5])

all_tasks.append(["exit by force on the horizontal bar, try max", 6, 3, 5])
all_tasks.append(["run 6 km", 6, 1, 5])
all_tasks.append(["push ups, 70", 6, 2, 5])

all_tasks.append(["jogging 15 km", 7, 1, 5])
all_tasks.append(["bulgarian squats 80% out of your max", 7, 5, 5])
all_tasks.append(["pull ups 40 times", 7, 1, 5])
